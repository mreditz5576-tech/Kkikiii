# Deploying on a VPS (Ubuntu/Debian)

## Option A – systemd (no Docker)
```bash
sudo apt update && sudo apt install -y python3 python3-venv tesseract-ocr
sudo useradd -r -m -d /opt/mlbbshop mlbbshop
sudo cp -r . /opt/mlbbshop && cd /opt/mlbbshop
sudo -u mlbbshop python3 -m venv .venv
sudo -u mlbbshop .venv/bin/pip install -r requirements.txt
sudo -u mlbbshop mkdir -p data
sudo -u mlbbshop cp .env.example .env && sudo -u mlbbshop nano .env   # fill BOT_TOKEN, OWNER_ID ...
sudo chmod 600 .env
sudo cp mlbbshop.service /etc/systemd/system/
sudo systemctl daemon-reload && sudo systemctl enable --now mlbbshop
journalctl -u mlbbshop -f        # logs
```

## Option B – Docker
```bash
cp .env.example .env && nano .env
docker compose up -d --build
docker compose logs -f
```

Back up `data/` (SQLite DB + cookies.json) regularly.
Run only ONE instance per bot token, otherwise Telegram returns "Conflict" errors.
